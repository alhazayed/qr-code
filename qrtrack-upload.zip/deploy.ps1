# QRTrack — One-Command Deploy to Vercel
# Run this from the qrtrack folder in PowerShell:
#   .\deploy.ps1

Write-Host ""
Write-Host "⬡ QRTrack Deploy Script" -ForegroundColor Cyan
Write-Host "========================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Node.js not found. Please install from https://nodejs.org" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Node.js found: $(node --version)" -ForegroundColor Green

# Install dependencies
Write-Host ""
Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -ne 0) { Write-Host "❌ npm install failed" -ForegroundColor Red; exit 1 }

# Install Vercel CLI if not present
if (-not (Get-Command vercel -ErrorAction SilentlyContinue)) {
    Write-Host ""
    Write-Host "📦 Installing Vercel CLI..." -ForegroundColor Yellow
    npm install -g vercel
}
Write-Host "✅ Vercel CLI ready" -ForegroundColor Green

# Deploy
Write-Host ""
Write-Host "🚀 Deploying to Vercel..." -ForegroundColor Yellow
Write-Host "(You'll be asked to log in to Vercel on first run)" -ForegroundColor Gray
Write-Host ""

vercel deploy --prod `
    --env NEXT_PUBLIC_SUPABASE_URL=https://cvzxpheodzrsjvqjkjbn.supabase.co `
    --env "NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN2enhwaGVvZHpyc2p2cWpramJuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkwMTI5MDYsImV4cCI6MjA5NDU4ODkwNn0.a0J649GcrdNBrLSDx2eMKCWMSskWXzVQicRju-QEpHk" `
    --yes

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✅ Deployed! Copy the URL above and run step 2:" -ForegroundColor Green
    Write-Host ""
    Write-Host "   vercel env add NEXT_PUBLIC_APP_URL production" -ForegroundColor Cyan
    Write-Host "   (paste your .vercel.app URL when prompted)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "   Then redeploy:" -ForegroundColor Yellow
    Write-Host "   vercel deploy --prod --yes" -ForegroundColor Cyan
} else {
    Write-Host "❌ Deployment failed." -ForegroundColor Red
}
